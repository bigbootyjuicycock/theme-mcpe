#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>
#import <objc/runtime.h>
#import <rootless.h>

#define MC_ROOT ROOT_PATH_NS(@"/Library/Application Support/MCHome")
#define RGB(r,g,b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1]

struct SBIconImageInfo { CGSize size; double scale; double continuousCornerRadius; };

@interface SBApplicationIcon : NSObject
- (NSString *)applicationBundleID;
@end
@interface SBCalendarApplicationIcon : SBApplicationIcon
@end
@interface SBDockView : UIView
- (void)mc_updateDock;
@end
@interface PSSpecifier : NSObject
- (NSString *)identifier;
@end
@interface PSTableCell : UITableViewCell
- (PSSpecifier *)specifier;
@end

#pragma mark - Images

static UIImage *MCSource(NSString *name) {
    static NSCache *cache; static dispatch_once_t once;
    dispatch_once(&once, ^{ cache = [NSCache new]; });
    if (!name.length) return nil;
    id hit = [cache objectForKey:name];
    if (hit) return hit == (id)[NSNull null] ? nil : hit;
    NSString *suffix = [UIScreen mainScreen].scale >= 3 ? @"@3x" : @"@2x";
    NSString *path = [NSString stringWithFormat:@"%@/Icons/%@%@.png", MC_ROOT, name, suffix];
    UIImage *img = [UIImage imageWithContentsOfFile:path];
    [cache setObject:(img ?: (id)[NSNull null]) forKey:name];
    return img;
}

static UIImage *MCRender(UIImage *src, CGSize size, CGFloat scale) {
    if (!src || size.width <= 0 || size.height <= 0) return nil;
    UIGraphicsImageRendererFormat *f = [UIGraphicsImageRendererFormat preferredFormat];
    f.scale = scale > 0 ? scale : [UIScreen mainScreen].scale;
    f.opaque = NO;
    UIGraphicsImageRenderer *r = [[UIGraphicsImageRenderer alloc] initWithSize:size format:f];
    return [r imageWithActions:^(UIGraphicsImageRendererContext *ctx) {
        CGContextSetInterpolationQuality(ctx.CGContext, kCGInterpolationNone);
        [src drawInRect:CGRectMake(0, 0, size.width, size.height)];
    }];
}

static void MCFill(UIColor *c, CGFloat x, CGFloat y, CGFloat w, CGFloat h) {
    [c setFill];
    UIRectFill(CGRectMake(x, y, w, h));
}

#pragma mark - Dock

@interface MCDockPanel : UIView
@property (nonatomic, copy) NSArray<NSValue *> *centers;
@end

@implementation MCDockPanel
- (void)drawRect:(CGRect)rect {
    CGFloat W = self.bounds.size.width, H = self.bounds.size.height, u = 3;
    // vien den, goc cat kieu pixel
    MCFill(UIColor.blackColor, u, 0, W - 2*u, H);
    MCFill(UIColor.blackColor, 0, u, W, H - 2*u);
    MCFill(RGB(198,198,198), u, u, W - 2*u, H - 2*u);
    MCFill(UIColor.whiteColor, u, u, W - 3*u, u);
    MCFill(UIColor.whiteColor, u, u, u, H - 3*u);
    MCFill(RGB(85,85,85), 2*u, H - 2*u, W - 3*u, u);
    MCFill(RGB(85,85,85), W - 2*u, 2*u, u, H - 3*u);

    NSArray<NSValue *> *list = self.centers;
    if (!list.count) {
        NSMutableArray *m = [NSMutableArray array];
        for (int i = 0; i < 4; i++)
            [m addObject:[NSValue valueWithCGPoint:CGPointMake(W * (57 + 87 * i) / 375.0, H / 2)]];
        list = m;
    }
    CGFloat pitch = W * 87.0 / 375.0;
    for (NSUInteger i = 1; i < list.count; i++) {
        CGFloat d = list[i].CGPointValue.x - list[i-1].CGPointValue.x;
        if (d > 40) pitch = MIN(pitch, d);
    }
    for (NSValue *v in list) {
        CGPoint c = v.CGPointValue;
        CGFloat w = floor(pitch - u), h = floor(MIN(w, H - 6*u));
        CGFloat x = floor(c.x - w/2), y = floor(c.y - h/2);
        y = MAX(3*u, MIN(y, H - 3*u - h));
        MCFill(RGB(139,139,139), x, y, w, h);
        MCFill(RGB(55,55,55), x, y, w - u, u);
        MCFill(RGB(55,55,55), x, y, u, h - u);
        MCFill(UIColor.whiteColor, x + u, y + h - u, w - u, u);
        MCFill(UIColor.whiteColor, x + w - u, y + u, u, h - u);
    }
}
@end

static void MCCollectIcons(UIView *view, UIView *target, NSMutableArray *out) {
    Class iconClass = NSClassFromString(@"SBIconView");
    for (UIView *sub in view.subviews) {
        if (iconClass && [sub isKindOfClass:iconClass]) {
            if (sub.hidden || sub.bounds.size.width < 20) continue;
            CGPoint p = [view convertPoint:sub.center toView:target];
            if (p.x > 0 && p.x < target.bounds.size.width)
                [out addObject:[NSValue valueWithCGPoint:p]];
        } else {
            MCCollectIcons(sub, target, out);
        }
    }
}

static char kMCPanelKey;

%group SpringBoardHooks

%hook SBApplicationIcon
- (UIImage *)generateIconImageWithInfo:(struct SBIconImageInfo)info {
    UIImage *orig = %orig;
    UIImage *mine = MCRender(MCSource([self applicationBundleID]), info.size, info.scale);
    return mine ?: orig;
}
%end

%hook SBCalendarApplicationIcon
- (UIImage *)generateIconImageWithInfo:(struct SBIconImageInfo)info {
    UIImage *orig = %orig;
    UIImage *mine = MCRender(MCSource(@"com.apple.mobilecal"), info.size, info.scale);
    return mine ?: orig;
}
%end

%hook SBDockView
- (void)layoutSubviews {
    %orig;
    [self mc_updateDock];
    __weak SBDockView *weakSelf = self;
    dispatch_async(dispatch_get_main_queue(), ^{ [weakSelf mc_updateDock]; });
}

%new
- (void)mc_updateDock {
    if (UIDevice.currentDevice.userInterfaceIdiom != UIUserInterfaceIdiomPhone) return;
    Ivar ivar = class_getInstanceVariable([self class], "_backgroundView");
    UIView *bg = ivar ? object_getIvar(self, ivar) : nil;
    if (!bg || !bg.superview) return;
    CGRect bgFrame = [bg.superview convertRect:bg.frame toView:self];
    if (bgFrame.size.height < 40) return;

    MCDockPanel *panel = objc_getAssociatedObject(self, &kMCPanelKey);
    if (!panel) {
        panel = [MCDockPanel new];
        panel.opaque = NO;
        panel.backgroundColor = UIColor.clearColor;
        panel.userInteractionEnabled = NO;
        objc_setAssociatedObject(self, &kMCPanelKey, panel, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    if (panel.superview != self) [self insertSubview:panel atIndex:0];
    bg.hidden = YES;
    // tran vien hai ben
    panel.frame = CGRectMake(0, bgFrame.origin.y, self.bounds.size.width, bgFrame.size.height);

    NSMutableArray *centers = [NSMutableArray array];
    MCCollectIcons(self, panel, centers);
    [centers sortUsingComparator:^NSComparisonResult(NSValue *a, NSValue *b) {
        return [@(a.CGPointValue.x) compare:@(b.CGPointValue.x)];
    }];
    panel.centers = centers;
    [panel setNeedsDisplay];
}
%end

%end

#pragma mark - Settings

static UIFont *MCFont(CGFloat size) {
    static NSString *name; static dispatch_once_t once;
    dispatch_once(&once, ^{
        NSURL *url = [NSURL fileURLWithPath:[MC_ROOT stringByAppendingPathComponent:@"font.ttf"]];
        CFArrayRef list = CTFontManagerCreateFontDescriptorsFromURL((__bridge CFURLRef)url);
        if (list) {
            if (CFArrayGetCount(list) > 0) {
                CTFontManagerRegisterFontsForURL((__bridge CFURLRef)url, kCTFontManagerScopeProcess, NULL);
                CTFontDescriptorRef d = (CTFontDescriptorRef)CFArrayGetValueAtIndex(list, 0);
                name = CFBridgingRelease(CTFontDescriptorCopyAttribute(d, kCTFontNameAttribute));
            }
            CFRelease(list);
        }
    });
    UIFont *f = name ? [UIFont fontWithName:name size:size] : nil;
    return f ?: ([UIFont fontWithName:@"Menlo-Bold" size:size - 1] ?: [UIFont boldSystemFontOfSize:size]);
}

static void MCStyleLabel(UILabel *l, UIColor *color) {
    if (!l) return;
    UIFont *f = MCFont(l.font.pointSize > 0 ? MIN(l.font.pointSize, 20) : 16);
    // tranh lap layout: chi doi font khi khac ho font
    if (![l.font.familyName isEqualToString:f.familyName]) l.font = f;
    l.textColor = color;
    l.shadowColor = RGB(62,54,50);
    l.shadowOffset = CGSizeMake(1.5, 1.5);
    l.backgroundColor = UIColor.clearColor;
}

@interface MCRowView : UIView
@property (nonatomic) BOOL pressed;
@end

@implementation MCRowView
- (instancetype)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) self.contentMode = UIViewContentModeRedraw;
    return self;
}
- (void)drawRect:(CGRect)rect {
    CGFloat W = self.bounds.size.width, H = self.bounds.size.height;
    CGColorSpaceRef space = CGColorSpaceCreateDeviceRGB();
    NSArray *colors = self.pressed
        ? @[(id)RGB(95,84,79).CGColor, (id)RGB(130,117,110).CGColor]
        : @[(id)RGB(178,164,155).CGColor, (id)RGB(158,143,135).CGColor];
    CGGradientRef g = CGGradientCreateWithColors(space, (__bridge CFArrayRef)colors, NULL);
    CGContextDrawLinearGradient(UIGraphicsGetCurrentContext(), g, CGPointZero, CGPointMake(0, H), 0);
    CGGradientRelease(g);
    CGColorSpaceRelease(space);
    MCFill(RGB(196,183,174), 0, 0, W, 2);
    MCFill(RGB(196,183,174), 0, 0, 2, H);
    MCFill(RGB(92,80,74), 0, H - 3, W, 3);
    MCFill(RGB(120,106,99), W - 2, 0, 2, H);
}
@end

static NSString *MCNormalize(NSString *s) {
    NSString *n = s.precomposedStringWithCanonicalMapping.lowercaseString;
    NSCharacterSet *drop = NSCharacterSet.alphanumericCharacterSet.invertedSet;
    return [[n componentsSeparatedByCharactersInSet:drop] componentsJoinedByString:@""];
}

static NSString *MCSettingKey(NSString *text) {
    static NSDictionary *map; static dispatch_once_t once;
    dispatch_once(&once, ^{
        NSDictionary *groups = @{
            @"set.airplane": @[@"AIRPLANE_MODE", @"Airplane Mode", @"Chế độ máy bay"],
            @"set.wifi": @[@"WIFI", @"Wi-Fi"],
            @"set.bluetooth": @[@"Bluetooth"],
            @"set.cellular": @[@"MOBILE_DATA_SETTINGS_ID", @"Cellular", @"Mobile Data", @"Di động", @"Dữ liệu di động"],
            @"set.hotspot": @[@"INTERNET_TETHERING", @"Personal Hotspot", @"Điểm truy cập cá nhân"],
            @"set.vpn": @[@"VPN"],
            @"set.notifications": @[@"NOTIFICATIONS_ID", @"Notifications", @"Thông báo"],
            @"set.sounds": @[@"Sounds", @"Sounds & Haptics", @"Âm thanh", @"Âm thanh & Cảm ứng"],
            @"set.focus": @[@"DO_NOT_DISTURB", @"Focus", @"Do Not Disturb", @"Tập trung", @"Không làm phiền"],
            @"set.screentime": @[@"SCREEN_TIME", @"Screen Time", @"Thời gian sử dụng"],
            @"com.apple.Preferences": @[@"General", @"Cài đặt chung"],
            @"set.controlcenter": @[@"ControlCenter", @"Control Center", @"Trung tâm điều khiển"],
            @"set.display": @[@"DISPLAY", @"Display & Brightness", @"Màn hình & Độ sáng"],
            @"set.homescreen": @[@"HOMESCREEN", @"Home Screen", @"Màn hình chính", @"Home Screen & Dock"],
            @"set.accessibility": @[@"ACCESSIBILITY", @"Accessibility", @"Trợ năng"],
            @"set.wallpaper": @[@"Wallpaper", @"Hình nền"],
            @"set.siri": @[@"SIRI", @"Siri & Search", @"Siri & Tìm kiếm"],
            @"set.search": @[@"SEARCH_ID", @"Spotlight Search", @"Tìm kiếm"],
            @"set.touchid": @[@"TOUCHID_PASSCODE", @"Touch ID & Passcode", @"Touch ID & Mật mã"],
            @"set.faceid": @[@"PASSCODE", @"Face ID & Passcode", @"Face ID & Mật mã"],
            @"set.sos": @[@"EMERGENCY_SOS", @"Emergency SOS", @"SOS khẩn cấp"],
            @"set.exposure": @[@"EXPOSURE_NOTIFICATION", @"Exposure Notifications", @"Thông báo phơi nhiễm"],
            @"set.battery": @[@"BATTERY_USAGE", @"Battery", @"Pin"],
            @"set.privacy": @[@"Privacy", @"Privacy & Security", @"Quyền riêng tư", @"Quyền riêng tư & Bảo mật"],
            @"set.passwords": @[@"PASSWORDS", @"ACCOUNTS_AND_PASSWORDS", @"Passwords", @"Passwords & Accounts", @"Mật khẩu", @"Mật khẩu & Tài khoản"],
            @"set.update": @[@"SOFTWARE_UPDATE_LINK", @"Software Update", @"Cập nhật phần mềm"],
            @"set.about": @[@"About", @"Giới thiệu"],
            @"set.keyboard": @[@"Keyboard", @"Bàn phím"],
            @"set.language": @[@"INTERNATIONAL", @"Language & Region", @"Ngôn ngữ & Vùng"],
            @"set.storage": @[@"STORAGE_MGMT", @"iPhone Storage", @"Dung lượng iPhone"],
            @"com.apple.AppStore": @[@"STORE", @"App Store", @"iTunes & App Store"],
            @"com.apple.Passbook": @[@"PASSBOOK", @"Wallet & Apple Pay", @"Ví & Apple Pay"],
            @"com.apple.mobilemail": @[@"MAIL", @"Mail"],
            @"com.apple.MobileAddressBook": @[@"CONTACTS", @"Contacts", @"Danh bạ"],
            @"com.apple.mobilecal": @[@"CALENDAR", @"Calendar", @"Lịch"],
            @"com.apple.mobilenotes": @[@"NOTES", @"Notes", @"Ghi chú"],
            @"com.apple.reminders": @[@"REMINDERS", @"Reminders", @"Lời nhắc"],
            @"com.apple.mobilephone": @[@"Phone", @"Điện thoại"],
            @"com.apple.MobileSMS": @[@"MESSAGES", @"Messages", @"Tin nhắn"],
            @"com.apple.facetime": @[@"FACETIME", @"FaceTime"],
            @"com.apple.mobilesafari": @[@"SAFARI", @"Safari"],
            @"com.apple.Maps": @[@"MAPS", @"Maps", @"Bản đồ"],
            @"com.apple.Music": @[@"MUSIC", @"Music", @"Nhạc"],
            @"com.apple.mobileslideshow": @[@"Photos", @"Ảnh"],
            @"com.apple.camera": @[@"CAMERA", @"Camera"],
            @"com.apple.Health": @[@"HEALTH", @"Health", @"Sức khỏe"],
        };
        NSMutableDictionary *m = [NSMutableDictionary dictionary];
        for (NSString *key in groups)
            for (NSString *alias in groups[key]) m[MCNormalize(alias)] = key;
        map = m;
    });
    return text.length ? map[MCNormalize(text)] : nil;
}

static char kMCIconKey, kMCRowKey, kMCNavKey;

static void MCReplaceIcon(UITableViewCell *cell) {
    UIImageView *iv = cell.imageView;
    if (!iv.image || iv.image.size.width > 40) return; // bo qua avatar Apple ID
    if (iv.image == objc_getAssociatedObject(iv, &kMCIconKey)) return;
    NSString *ident = nil;
    if ([cell respondsToSelector:@selector(specifier)]) {
        PSSpecifier *spec = [(PSTableCell *)cell specifier];
        if ([spec respondsToSelector:@selector(identifier)]) ident = [spec identifier];
    }
    UIImage *src = MCSource(ident) ?: MCSource(MCSettingKey(ident)) ?: MCSource(MCSettingKey(cell.textLabel.text));
    if (!src) {
        NSLog(@"[MCHome] thieu icon: id=%@ ten=%@", ident, cell.textLabel.text);
        return;
    }
    UIImage *img = MCRender(src, CGSizeMake(29, 29), 0);
    objc_setAssociatedObject(iv, &kMCIconKey, img, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    iv.image = img;
}

%group SettingsHooks

%hook UITableView
- (void)layoutSubviews {
    %orig;
    UIColor *base = objc_getAssociatedObject(self, &kMCRowKey);
    if (!base) {
        base = RGB(150,133,125);
        objc_setAssociatedObject(self, &kMCRowKey, base, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    if (![self.backgroundColor isEqual:base]) {
        self.backgroundView = nil;
        self.backgroundColor = base;
    }
    if (self.separatorStyle != UITableViewCellSeparatorStyleNone)
        self.separatorStyle = UITableViewCellSeparatorStyleNone;
}
%end

%hook UITableViewCell
- (void)layoutSubviews {
    %orig;
    if (![self.backgroundView isKindOfClass:[MCRowView class]])
        self.backgroundView = [[MCRowView alloc] initWithFrame:self.bounds];
    if (![self.selectedBackgroundView isKindOfClass:[MCRowView class]]) {
        MCRowView *down = [[MCRowView alloc] initWithFrame:self.bounds];
        down.pressed = YES;
        self.selectedBackgroundView = down;
    }
    self.backgroundColor = UIColor.clearColor;
    self.layer.cornerRadius = 0;

    MCReplaceIcon(self);

    BOOL enabled = self.userInteractionEnabled && (!self.textLabel || self.textLabel.enabled);
    UIColor *main = enabled ? UIColor.whiteColor : RGB(112,102,97);
    MCStyleLabel(self.textLabel, main);
    MCStyleLabel(self.detailTextLabel, RGB(232,224,216));

    // an mui ten ">" vi bang che do goc khong co
    if (self.accessoryType == UITableViewCellAccessoryDisclosureIndicator) {
        for (UIView *v in self.subviews)
            if (v != self.contentView && [v isKindOfClass:[UIButton class]]) v.hidden = YES;
    }

    // chu ben trai, icon ben phai
    UIImageView *iv = self.imageView;
    if (!iv.image || iv.image.size.width > 40) return;
    CGFloat W = self.contentView.bounds.size.width, H = self.contentView.bounds.size.height;
    CGFloat iconX = W - 29 - 12;
    iv.frame = CGRectMake(iconX, floor((H - 29) / 2), 29, 29);
    iv.layer.cornerRadius = 0;
    iv.layer.magnificationFilter = kCAFilterNearest;

    CGFloat right = iconX - 10;
    UILabel *title = self.textLabel, *detail = self.detailTextLabel;
    BOOL sameRow = detail.text.length && fabs(CGRectGetMidY(detail.frame) - CGRectGetMidY(title.frame)) < 8;
    if (sameRow) {
        CGFloat dw = MIN([detail sizeThatFits:CGSizeMake(W, H)].width, W * 0.35);
        detail.frame = CGRectMake(right - dw, detail.frame.origin.y, dw, detail.frame.size.height);
        right -= dw + 8;
    }
    CGRect tf = title.frame;
    tf.origin.x = 16;
    tf.size.width = MAX(0, right - 16);
    title.frame = tf;
    title.adjustsFontSizeToFitWidth = YES;
    title.minimumScaleFactor = 0.7;
    if (detail.text.length && !sameRow) {
        CGRect df = detail.frame;
        df.origin.x = 16;
        df.size.width = MAX(0, right - 16);
        detail.frame = df;
    }
}
%end

%hook UITableViewHeaderFooterView
- (void)layoutSubviews {
    %orig;
    MCStyleLabel(self.textLabel, UIColor.whiteColor);
    MCStyleLabel(self.detailTextLabel, UIColor.whiteColor);
}
%end

%hook UINavigationBar
- (void)didMoveToWindow {
    %orig;
    if (!self.window || objc_getAssociatedObject(self, &kMCNavKey)) return;
    objc_setAssociatedObject(self, &kMCNavKey, @YES, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    UINavigationBarAppearance *a = [UINavigationBarAppearance new];
    [a configureWithOpaqueBackground];
    a.backgroundColor = RGB(114,100,94);
    a.titleTextAttributes = @{NSForegroundColorAttributeName: UIColor.whiteColor, NSFontAttributeName: MCFont(17)};
    a.largeTitleTextAttributes = @{NSForegroundColorAttributeName: UIColor.whiteColor, NSFontAttributeName: MCFont(30)};
    self.standardAppearance = a;
    self.scrollEdgeAppearance = a;
    self.compactAppearance = a;
    self.tintColor = UIColor.whiteColor;
}
%end

%end

%ctor {
    NSString *bundle = NSBundle.mainBundle.bundleIdentifier;
    if ([bundle isEqualToString:@"com.apple.springboard"]) {
        %init(SpringBoardHooks);
    } else if ([bundle isEqualToString:@"com.apple.Preferences"]) {
        %init(SettingsHooks);
    }
}
